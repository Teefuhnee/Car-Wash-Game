Name: Tiffany Tran
Email: trantt5@uci.edu
ID #: 33128070

The goal of the game is to shoot the incoming cars with water bullets. The player is to score 5000 to beat the game. The player will lose lives when the player fails to hit the cars or when the car hits them. The feeling I wanted was to create stress when trying to hit the incoming cars.
